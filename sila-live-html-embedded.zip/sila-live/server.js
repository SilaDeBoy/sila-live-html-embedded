const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, app: "Sila Live" }));

// Demo rooms are kept in memory. Use a database and a media server for production.
const rooms = new Map();
function getRoom(id) {
  if (!rooms.has(id)) rooms.set(id, { host: null, viewers: new Set(), title: "Live stream", messages: [] });
  return rooms.get(id);
}
function roomStats(id) {
  const room = getRoom(id);
  return { roomId: id, live: Boolean(room.host), viewers: room.viewers.size, title: room.title };
}

io.on("connection", socket => {
  socket.on("join-room", ({ roomId, role, name, title } = {}) => {
    roomId = String(roomId || "main").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 50) || "main";
    role = role === "host" ? "host" : "viewer";
    socket.data.roomId = roomId;
    socket.data.role = role;
    socket.data.name = String(name || (role === "host" ? "Creator" : "Viewer")).slice(0, 32);
    socket.join(roomId);
    const room = getRoom(roomId);
    if (role === "host") {
      room.host = socket.id;
      if (title) room.title = String(title).slice(0, 100);
    } else {
      room.viewers.add(socket.id);
    }
    socket.emit("room-state", { ...roomStats(roomId), messages: room.messages.slice(-60), hostId: room.host });
    io.to(roomId).emit("room-stats", roomStats(roomId));
    if (role === "viewer" && room.host) io.to(room.host).emit("viewer-joined", { viewerId: socket.id });
    if (role === "host") socket.to(roomId).emit("host-ready", { hostId: socket.id });
  });

  // WebRTC signaling relay. Media flows peer-to-peer in this starter.
  socket.on("webrtc-offer", ({ to, offer }) => io.to(to).emit("webrtc-offer", { from: socket.id, offer }));
  socket.on("webrtc-answer", ({ to, answer }) => io.to(to).emit("webrtc-answer", { from: socket.id, answer }));
  socket.on("webrtc-ice", ({ to, candidate }) => io.to(to).emit("webrtc-ice", { from: socket.id, candidate }));

  socket.on("chat-message", ({ text } = {}) => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    const clean = String(text || "").trim().slice(0, 500);
    if (!clean) return;
    const message = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name: socket.data.name || "Viewer", text: clean, time: new Date().toISOString() };
    const room = getRoom(roomId);
    room.messages.push(message);
    if (room.messages.length > 100) room.messages.shift();
    io.to(roomId).emit("chat-message", message);
  });

  socket.on("stream-ended", () => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    const room = getRoom(roomId);
    if (room.host === socket.id) {
      room.host = null;
      socket.to(roomId).emit("stream-ended");
      io.to(roomId).emit("room-stats", roomStats(roomId));
    }
  });

  socket.on("disconnect", () => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    const room = getRoom(roomId);
    room.viewers.delete(socket.id);
    if (room.host === socket.id) {
      room.host = null;
      socket.to(roomId).emit("stream-ended");
    }
    io.to(roomId).emit("room-stats", roomStats(roomId));
  });
});

server.listen(PORT, () => console.log(`Sila Live running at http://localhost:${PORT}`));
