# Sila Live

A responsive live-streaming website starter with a creator studio, camera/microphone preview, live-room links, real-time chat, viewer counts, and WebRTC video signaling.

## Requirements

- Node.js 18 or newer
- A modern browser
- Camera/microphone permission for broadcasting

## Run locally

1. Extract this ZIP.
2. Open a terminal in the extracted `sila-live` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open **http://localhost:3000**.

Use **Creator studio** to enable the camera and click **Go live**. Copy the room link and open it in another browser/device to test joining. Camera access works on `localhost`; for public deployment, use HTTPS.

## Included

- Responsive home page and stream discovery cards
- Category filtering and search
- Creator studio with camera/mic toggles and preview
- Room URL sharing
- Socket.IO live chat and room viewer count
- WebRTC signaling for live camera video
- Basic server health endpoint at `/health`

## Important limitations

This is a starter/demo, not a production-scale YouTube replacement. The stream cards on Home/Explore are sample content. Real video broadcasts are peer-to-peer, which becomes unreliable and expensive as viewer counts grow. A production service should use an SFU/media server such as LiveKit, mediasoup, or Janus, and a TURN server for networks where direct WebRTC connectivity fails. The current server stores room state and chat in memory, so restarting it clears the state.

Before public launch, add authentication, creator profiles, database persistence, moderation/reporting, rate limiting, privacy controls, secure deployment, stream recording, and scalable media delivery. Never trust client-supplied names or room permissions in a production system.

## Deploy

Deploy the Node.js server to a host that supports persistent WebSocket connections. Configure `PORT` if the platform requires it. Set up HTTPS before allowing camera/microphone access on public domains. For real audience scale, replace peer-to-peer fan-out with an SFU.

## Project layout

```text
sila-live/
├── server.js
├── package.json
├── .env.example
├── README.md
└── public/
    ├── index.html
    ├── styles.css
    └── app.js
```
